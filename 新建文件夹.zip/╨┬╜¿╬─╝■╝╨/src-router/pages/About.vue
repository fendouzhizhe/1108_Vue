<template>
  <div>
    <h2>About</h2>
    <input type="text">
  </div>
</template>
<script>
export default {
  name: 'About'
}
</script>
<style scoped>
</style>
